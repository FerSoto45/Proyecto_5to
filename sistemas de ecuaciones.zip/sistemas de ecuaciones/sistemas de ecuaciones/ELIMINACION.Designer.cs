﻿namespace sistemas_de_ecuaciones
{
    partial class ELIMINACION
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblResul = new System.Windows.Forms.Label();
            this.lblResulQ3 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblResulQ2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblResulq1 = new System.Windows.Forms.Label();
            this.lblTituloValores = new System.Windows.Forms.Label();
            this.lblTituloProc = new System.Windows.Forms.Label();
            this.lblXX = new System.Windows.Forms.Label();
            this.lblX = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblMostrarSoluY = new System.Windows.Forms.Label();
            this.lblMostrarSoluc = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txta2 = new System.Windows.Forms.TextBox();
            this.txtb2 = new System.Windows.Forms.TextBox();
            this.txtc2 = new System.Windows.Forms.TextBox();
            this.txtb1 = new System.Windows.Forms.TextBox();
            this.txtc1 = new System.Windows.Forms.TextBox();
            this.txta1 = new System.Windows.Forms.TextBox();
            this.btnResolver = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(75, 390);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 20);
            this.label12.TabIndex = 113;
            this.label12.Text = "22";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(75, 346);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 20);
            this.label10.TabIndex = 112;
            this.label10.Text = "11";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(39, 295);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 23);
            this.label8.TabIndex = 111;
            this.label8.Text = "FACTOR";
            this.label8.Visible = false;
            // 
            // lblResul
            // 
            this.lblResul.AutoSize = true;
            this.lblResul.Location = new System.Drawing.Point(426, 495);
            this.lblResul.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblResul.Name = "lblResul";
            this.lblResul.Size = new System.Drawing.Size(18, 20);
            this.lblResul.TabIndex = 110;
            this.lblResul.Text = "7";
            // 
            // lblResulQ3
            // 
            this.lblResulQ3.AutoSize = true;
            this.lblResulQ3.Location = new System.Drawing.Point(694, 390);
            this.lblResulQ3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblResulQ3.Name = "lblResulQ3";
            this.lblResulQ3.Size = new System.Drawing.Size(18, 20);
            this.lblResulQ3.TabIndex = 109;
            this.lblResulQ3.Text = "6";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(693, 346);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 20);
            this.label13.TabIndex = 108;
            this.label13.Text = "3";
            // 
            // lblResulQ2
            // 
            this.lblResulQ2.AutoSize = true;
            this.lblResulQ2.Location = new System.Drawing.Point(525, 390);
            this.lblResulQ2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblResulQ2.Name = "lblResulQ2";
            this.lblResulQ2.Size = new System.Drawing.Size(18, 20);
            this.lblResulQ2.TabIndex = 107;
            this.lblResulQ2.Text = "5";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(525, 346);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 20);
            this.label11.TabIndex = 106;
            this.label11.Text = "2";
            // 
            // lblResulq1
            // 
            this.lblResulq1.AutoSize = true;
            this.lblResulq1.Location = new System.Drawing.Point(369, 390);
            this.lblResulq1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblResulq1.Name = "lblResulq1";
            this.lblResulq1.Size = new System.Drawing.Size(18, 20);
            this.lblResulq1.TabIndex = 105;
            this.lblResulq1.Text = "4";
            // 
            // lblTituloValores
            // 
            this.lblTituloValores.AutoSize = true;
            this.lblTituloValores.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloValores.Location = new System.Drawing.Point(39, 441);
            this.lblTituloValores.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTituloValores.Name = "lblTituloValores";
            this.lblTituloValores.Size = new System.Drawing.Size(123, 23);
            this.lblTituloValores.TabIndex = 104;
            this.lblTituloValores.Text = "CALCULO X Y ";
            this.lblTituloValores.Visible = false;
            // 
            // lblTituloProc
            // 
            this.lblTituloProc.AutoSize = true;
            this.lblTituloProc.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloProc.Location = new System.Drawing.Point(316, 295);
            this.lblTituloProc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTituloProc.Name = "lblTituloProc";
            this.lblTituloProc.Size = new System.Drawing.Size(132, 23);
            this.lblTituloProc.TabIndex = 103;
            this.lblTituloProc.Text = "ELIMINACION";
            this.lblTituloProc.Visible = false;
            // 
            // lblXX
            // 
            this.lblXX.AutoSize = true;
            this.lblXX.Location = new System.Drawing.Point(158, 495);
            this.lblXX.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblXX.Name = "lblXX";
            this.lblXX.Size = new System.Drawing.Size(36, 20);
            this.lblXX.TabIndex = 102;
            this.lblXX.Text = "111";
            this.lblXX.Visible = false;
            // 
            // lblX
            // 
            this.lblX.AutoSize = true;
            this.lblX.Location = new System.Drawing.Point(369, 346);
            this.lblX.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblX.Name = "lblX";
            this.lblX.Size = new System.Drawing.Size(18, 20);
            this.lblX.TabIndex = 101;
            this.lblX.Text = "1";
            this.lblX.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(621, 727);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 46);
            this.label9.TabIndex = 98;
            this.label9.Text = "y";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(621, 641);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 46);
            this.label7.TabIndex = 97;
            this.label7.Text = "x";
            // 
            // lblMostrarSoluY
            // 
            this.lblMostrarSoluY.AutoSize = true;
            this.lblMostrarSoluY.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarSoluY.Location = new System.Drawing.Point(291, 727);
            this.lblMostrarSoluY.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMostrarSoluY.Name = "lblMostrarSoluY";
            this.lblMostrarSoluY.Size = new System.Drawing.Size(276, 46);
            this.lblMostrarSoluY.TabIndex = 96;
            this.lblMostrarSoluY.Text = "SOLUCION  Y";
            this.lblMostrarSoluY.Visible = false;
            // 
            // lblMostrarSoluc
            // 
            this.lblMostrarSoluc.AutoSize = true;
            this.lblMostrarSoluc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarSoluc.Location = new System.Drawing.Point(291, 641);
            this.lblMostrarSoluc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMostrarSoluc.Name = "lblMostrarSoluc";
            this.lblMostrarSoluc.Size = new System.Drawing.Size(266, 46);
            this.lblMostrarSoluc.TabIndex = 95;
            this.lblMostrarSoluc.Text = "SOLUCION X";
            this.lblMostrarSoluc.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(214, 180);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 29);
            this.label5.TabIndex = 94;
            this.label5.Text = "+";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(214, 107);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 29);
            this.label4.TabIndex = 93;
            this.label4.Text = "+";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(315, 106);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 29);
            this.label3.TabIndex = 92;
            this.label3.Text = "=";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(315, 178);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 29);
            this.label2.TabIndex = 91;
            this.label2.Text = "=";
            // 
            // txta2
            // 
            this.txta2.Location = new System.Drawing.Point(144, 178);
            this.txta2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txta2.Name = "txta2";
            this.txta2.Size = new System.Drawing.Size(55, 26);
            this.txta2.TabIndex = 90;
            // 
            // txtb2
            // 
            this.txtb2.Location = new System.Drawing.Point(250, 178);
            this.txtb2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtb2.Name = "txtb2";
            this.txtb2.Size = new System.Drawing.Size(54, 26);
            this.txtb2.TabIndex = 89;
            // 
            // txtc2
            // 
            this.txtc2.Location = new System.Drawing.Point(351, 181);
            this.txtc2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtc2.Name = "txtc2";
            this.txtc2.Size = new System.Drawing.Size(44, 26);
            this.txtc2.TabIndex = 88;
            // 
            // txtb1
            // 
            this.txtb1.Location = new System.Drawing.Point(250, 104);
            this.txtb1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtb1.Name = "txtb1";
            this.txtb1.Size = new System.Drawing.Size(54, 26);
            this.txtb1.TabIndex = 87;
            // 
            // txtc1
            // 
            this.txtc1.Location = new System.Drawing.Point(351, 104);
            this.txtc1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtc1.Name = "txtc1";
            this.txtc1.Size = new System.Drawing.Size(44, 26);
            this.txtc1.TabIndex = 86;
            // 
            // txta1
            // 
            this.txta1.Location = new System.Drawing.Point(144, 104);
            this.txta1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txta1.Name = "txta1";
            this.txta1.Size = new System.Drawing.Size(55, 26);
            this.txta1.TabIndex = 85;
            // 
            // btnResolver
            // 
            this.btnResolver.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResolver.Location = new System.Drawing.Point(549, 107);
            this.btnResolver.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnResolver.Name = "btnResolver";
            this.btnResolver.Size = new System.Drawing.Size(112, 35);
            this.btnResolver.TabIndex = 114;
            this.btnResolver.Text = "RESOLVER";
            this.btnResolver.UseVisualStyleBackColor = true;
            this.btnResolver.Click += new System.EventHandler(this.btnResolver_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiar.Location = new System.Drawing.Point(698, 107);
            this.btnLimpiar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(112, 35);
            this.btnLimpiar.TabIndex = 115;
            this.btnLimpiar.Text = "LIMPIAR";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            // 
            // ELIMINACION
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(881, 802);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnResolver);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblResul);
            this.Controls.Add(this.lblResulQ3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblResulQ2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblResulq1);
            this.Controls.Add(this.lblTituloValores);
            this.Controls.Add(this.lblTituloProc);
            this.Controls.Add(this.lblXX);
            this.Controls.Add(this.lblX);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblMostrarSoluY);
            this.Controls.Add(this.lblMostrarSoluc);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txta2);
            this.Controls.Add(this.txtb2);
            this.Controls.Add(this.txtc2);
            this.Controls.Add(this.txtb1);
            this.Controls.Add(this.txtc1);
            this.Controls.Add(this.txta1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "ELIMINACION";
            this.Text = "ELIMINACION";
            this.Load += new System.EventHandler(this.ELIMINACION_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblResul;
        private System.Windows.Forms.Label lblResulQ3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblResulQ2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblResulq1;
        private System.Windows.Forms.Label lblTituloValores;
        private System.Windows.Forms.Label lblTituloProc;
        private System.Windows.Forms.Label lblXX;
        private System.Windows.Forms.Label lblX;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblMostrarSoluY;
        private System.Windows.Forms.Label lblMostrarSoluc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txta2;
        private System.Windows.Forms.TextBox txtb2;
        private System.Windows.Forms.TextBox txtc2;
        private System.Windows.Forms.TextBox txtb1;
        private System.Windows.Forms.TextBox txtc1;
        private System.Windows.Forms.TextBox txta1;
        private System.Windows.Forms.Button btnResolver;
        private System.Windows.Forms.Button btnLimpiar;
    }
}