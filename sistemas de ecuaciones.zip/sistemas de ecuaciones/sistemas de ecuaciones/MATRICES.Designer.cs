﻿namespace sistemas_de_ecuaciones
{
    partial class MATRICES
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblIndependiente = new System.Windows.Forms.Label();
            this.lblCoeficiente = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblRptY = new System.Windows.Forms.Label();
            this.lblRptX = new System.Windows.Forms.Label();
            this.lblMostrarSoluY = new System.Windows.Forms.Label();
            this.lblMostrarSoluc = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txta2 = new System.Windows.Forms.TextBox();
            this.txtb2 = new System.Windows.Forms.TextBox();
            this.txtc2 = new System.Windows.Forms.TextBox();
            this.txtb1 = new System.Windows.Forms.TextBox();
            this.txtc1 = new System.Windows.Forms.TextBox();
            this.txta1 = new System.Windows.Forms.TextBox();
            this.btnResolver = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblIndependiente
            // 
            this.lblIndependiente.AutoSize = true;
            this.lblIndependiente.Location = new System.Drawing.Point(275, 379);
            this.lblIndependiente.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndependiente.Name = "lblIndependiente";
            this.lblIndependiente.Size = new System.Drawing.Size(18, 20);
            this.lblIndependiente.TabIndex = 140;
            this.lblIndependiente.Text = "2";
            // 
            // lblCoeficiente
            // 
            this.lblCoeficiente.AutoSize = true;
            this.lblCoeficiente.Location = new System.Drawing.Point(275, 270);
            this.lblCoeficiente.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCoeficiente.Name = "lblCoeficiente";
            this.lblCoeficiente.Size = new System.Drawing.Size(18, 20);
            this.lblCoeficiente.TabIndex = 139;
            this.lblCoeficiente.Text = "1";
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Location = new System.Drawing.Point(39, 312);
            this.lbl7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(167, 20);
            this.lbl7.TabIndex = 138;
            this.lbl7.Text = "matriz Independientes";
            this.lbl7.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 213);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 20);
            this.label6.TabIndex = 137;
            this.label6.Text = "matriz Coeficientes";
            this.label6.Visible = false;
            // 
            // lblRptY
            // 
            this.lblRptY.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRptY.AutoSize = true;
            this.lblRptY.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRptY.Location = new System.Drawing.Point(453, 586);
            this.lblRptY.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRptY.Name = "lblRptY";
            this.lblRptY.Size = new System.Drawing.Size(46, 46);
            this.lblRptY.TabIndex = 136;
            this.lblRptY.Text = "Y";
            // 
            // lblRptX
            // 
            this.lblRptX.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRptX.AutoSize = true;
            this.lblRptX.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRptX.Location = new System.Drawing.Point(452, 493);
            this.lblRptX.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRptX.Name = "lblRptX";
            this.lblRptX.Size = new System.Drawing.Size(47, 46);
            this.lblRptX.TabIndex = 135;
            this.lblRptX.Text = "X";
            // 
            // lblMostrarSoluY
            // 
            this.lblMostrarSoluY.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMostrarSoluY.AutoSize = true;
            this.lblMostrarSoluY.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarSoluY.Location = new System.Drawing.Point(122, 586);
            this.lblMostrarSoluY.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMostrarSoluY.Name = "lblMostrarSoluY";
            this.lblMostrarSoluY.Size = new System.Drawing.Size(277, 46);
            this.lblMostrarSoluY.TabIndex = 134;
            this.lblMostrarSoluY.Text = "solucion de y: ";
            this.lblMostrarSoluY.Visible = false;
            // 
            // lblMostrarSoluc
            // 
            this.lblMostrarSoluc.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMostrarSoluc.AutoSize = true;
            this.lblMostrarSoluc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarSoluc.Location = new System.Drawing.Point(121, 493);
            this.lblMostrarSoluc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMostrarSoluc.Name = "lblMostrarSoluc";
            this.lblMostrarSoluc.Size = new System.Drawing.Size(278, 46);
            this.lblMostrarSoluc.TabIndex = 133;
            this.lblMostrarSoluc.Text = "solucion de x: ";
            this.lblMostrarSoluc.Visible = false;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(101, 141);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 29);
            this.label5.TabIndex = 132;
            this.label5.Text = "+";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(101, 70);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 29);
            this.label4.TabIndex = 131;
            this.label4.Text = "+";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(201, 67);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 29);
            this.label3.TabIndex = 130;
            this.label3.Text = "=";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(201, 140);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 29);
            this.label2.TabIndex = 129;
            this.label2.Text = "=";
            // 
            // txta2
            // 
            this.txta2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txta2.Location = new System.Drawing.Point(30, 140);
            this.txta2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txta2.Name = "txta2";
            this.txta2.Size = new System.Drawing.Size(0, 26);
            this.txta2.TabIndex = 128;
            // 
            // txtb2
            // 
            this.txtb2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtb2.Location = new System.Drawing.Point(137, 140);
            this.txtb2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtb2.Name = "txtb2";
            this.txtb2.Size = new System.Drawing.Size(0, 26);
            this.txtb2.TabIndex = 127;
            // 
            // txtc2
            // 
            this.txtc2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtc2.Location = new System.Drawing.Point(189, 140);
            this.txtc2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtc2.Name = "txtc2";
            this.txtc2.Size = new System.Drawing.Size(44, 26);
            this.txtc2.TabIndex = 126;
            // 
            // txtb1
            // 
            this.txtb1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtb1.Location = new System.Drawing.Point(137, 66);
            this.txtb1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtb1.Name = "txtb1";
            this.txtb1.Size = new System.Drawing.Size(0, 26);
            this.txtb1.TabIndex = 125;
            // 
            // txtc1
            // 
            this.txtc1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtc1.Location = new System.Drawing.Point(237, 65);
            this.txtc1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtc1.Name = "txtc1";
            this.txtc1.Size = new System.Drawing.Size(0, 26);
            this.txtc1.TabIndex = 124;
            // 
            // txta1
            // 
            this.txta1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txta1.Location = new System.Drawing.Point(30, 66);
            this.txta1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txta1.Name = "txta1";
            this.txta1.Size = new System.Drawing.Size(0, 26);
            this.txta1.TabIndex = 123;
            // 
            // btnResolver
            // 
            this.btnResolver.Location = new System.Drawing.Point(439, 92);
            this.btnResolver.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnResolver.Name = "btnResolver";
            this.btnResolver.Size = new System.Drawing.Size(84, 29);
            this.btnResolver.TabIndex = 141;
            this.btnResolver.Text = "button1";
            this.btnResolver.UseVisualStyleBackColor = true;
            this.btnResolver.Click += new System.EventHandler(this.btnResolver_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(548, 92);
            this.btnLimpiar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(84, 29);
            this.btnLimpiar.TabIndex = 142;
            this.btnLimpiar.Text = "button2";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            // 
            // MATRICES
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1091, 830);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnResolver);
            this.Controls.Add(this.lblIndependiente);
            this.Controls.Add(this.lblCoeficiente);
            this.Controls.Add(this.lbl7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblRptY);
            this.Controls.Add(this.lblRptX);
            this.Controls.Add(this.lblMostrarSoluY);
            this.Controls.Add(this.lblMostrarSoluc);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txta2);
            this.Controls.Add(this.txtb2);
            this.Controls.Add(this.txtc2);
            this.Controls.Add(this.txtb1);
            this.Controls.Add(this.txtc1);
            this.Controls.Add(this.txta1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MATRICES";
            this.Text = "MATRICES";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblIndependiente;
        private System.Windows.Forms.Label lblCoeficiente;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblRptY;
        private System.Windows.Forms.Label lblRptX;
        private System.Windows.Forms.Label lblMostrarSoluY;
        private System.Windows.Forms.Label lblMostrarSoluc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txta2;
        private System.Windows.Forms.TextBox txtb2;
        private System.Windows.Forms.TextBox txtc2;
        private System.Windows.Forms.TextBox txtb1;
        private System.Windows.Forms.TextBox txtc1;
        private System.Windows.Forms.TextBox txta1;
        private System.Windows.Forms.Button btnResolver;
        private System.Windows.Forms.Button btnLimpiar;
    }
}