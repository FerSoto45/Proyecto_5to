﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace sistemas_de_ecuaciones
{
    public partial class ELIPSE : Form
    {
        public ELIPSE()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Obtener los valores ingresados en los TextBoxes
            double centerX = double.Parse(txtCenterX.Text);
            double centerY = double.Parse(txtCenterY.Text);
            double semiMajorAxis = double.Parse(txtSemiMajorAxis.Text);
            double semiMinorAxis = double.Parse(txtSemiMinorAxis.Text);

            string procedure = "Procedimiento para obtener la ecuación de la elipse:\n";
            procedure += $"Paso 1: Obtener los valores ingresados.\n";
            procedure += $"Paso 2: El centro de la elipse es ({centerX}, {centerY}).\n";
            procedure += $"Paso 3: El semieje mayor tiene longitud {semiMajorAxis}.\n";
            procedure += $"Paso 4: El semieje menor tiene longitud {semiMinorAxis}.\n";
            procedure += $"Paso 5: Aplicar la fórmula de la elipse.\n";
            procedure += $"Paso 6: La ecuación de la elipse es: ((x - {centerX})^2 / {semiMajorAxis}^2) + ((y - {centerY})^2 / {semiMinorAxis}^2) = 1";
            
            // Mostrar el procedimiento en el Label
            lblProcedure.Text = procedure;
          
            
            // Limpiar la gráfica
            chart1.Series.Clear();

            // Crear una nueva serie para la elipse
            Series series = new Series();
            series.ChartType = SeriesChartType.Point;
            series.Color = Color.Blue;

            // Calcular los puntos de la elipse y agregarlos a la serie
            int numPoints = 100;
            for (int i = 0; i < numPoints; i++)
            {
                double angle = 2 * Math.PI * i / numPoints;
                double x = centerX + semiMajorAxis * Math.Cos(angle);
                double y = centerY + semiMinorAxis * Math.Sin(angle);
                series.Points.AddXY(x, y);


            }
            
            // Marcar el centro de la elipse en la gráfica
            Series centerSeries = new Series();
            centerSeries.ChartType = SeriesChartType.Point;
            centerSeries.Color = Color.Red;
            centerSeries.Points.AddXY(centerX, centerY);
            chart1.Series.Add(centerSeries);

            // Dibujar una línea vertical desde el centro de la elipse hasta el círculo superior
            Series lineVerticalSeries = new Series();
            lineVerticalSeries.ChartType = SeriesChartType.Line;
            lineVerticalSeries.Color = Color.Green;
            lineVerticalSeries.Points.AddXY(centerX, centerY - semiMinorAxis);
            lineVerticalSeries.Points.AddXY(centerX, centerY - semiMajorAxis);
            lineVerticalSeries.Points.AddXY(centerX, centerY);
            chart1.Series.Add(lineVerticalSeries);


            // Dibujar una línea horizontal desde el centro de la elipse hasta el círculo derecho
            Series lineHorizontalSeries = new Series();
            lineHorizontalSeries.ChartType = SeriesChartType.Line;
            lineHorizontalSeries.Color = Color.Orange;
            lineHorizontalSeries.Points.AddXY(centerX, centerY);
            lineHorizontalSeries.Points.AddXY(centerX + semiMajorAxis, centerY);
            chart1.Series.Add(lineHorizontalSeries);

            // Agregar la serie a la gráfica
            chart1.Series.Add(series);

            // Configurar los ejes
            chart1.ChartAreas[0].AxisX.Minimum = centerX - semiMajorAxis;
            chart1.ChartAreas[0].AxisX.Maximum = centerX + semiMajorAxis;
            chart1.ChartAreas[0].AxisX.Interval = .25;

            chart1.ChartAreas[0].AxisY.Minimum = centerY - semiMinorAxis;
            chart1.ChartAreas[0].AxisY.Maximum = centerY + semiMinorAxis;
            chart1.ChartAreas[0].AxisY.Interval = .25;
        }

        private void ELIPSE_Load(object sender, EventArgs e)
        {

        }
    }
    
}

     
        
 

