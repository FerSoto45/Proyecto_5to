﻿namespace sistemas_de_ecuaciones
{
    partial class IGUALACION
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnResolver = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.lblTituloY = new System.Windows.Forms.Label();
            this.lblTituloX = new System.Windows.Forms.Label();
            this.lblY = new System.Windows.Forms.Label();
            this.lblX = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblMostrarSoluY = new System.Windows.Forms.Label();
            this.lblMostrarSoluc = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txta2 = new System.Windows.Forms.TextBox();
            this.txtb2 = new System.Windows.Forms.TextBox();
            this.txtc2 = new System.Windows.Forms.TextBox();
            this.txtb1 = new System.Windows.Forms.TextBox();
            this.txtc1 = new System.Windows.Forms.TextBox();
            this.txta1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnResolver
            // 
            this.btnResolver.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResolver.Location = new System.Drawing.Point(631, 133);
            this.btnResolver.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btnResolver.Name = "btnResolver";
            this.btnResolver.Size = new System.Drawing.Size(124, 40);
            this.btnResolver.TabIndex = 2;
            this.btnResolver.Text = "RESOLVER";
            this.btnResolver.UseVisualStyleBackColor = true;
            this.btnResolver.Click += new System.EventHandler(this.btnResolver_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiar.Location = new System.Drawing.Point(791, 133);
            this.btnLimpiar.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(124, 40);
            this.btnLimpiar.TabIndex = 5;
            this.btnLimpiar.Text = "LIMPIAR";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            // 
            // lblTituloY
            // 
            this.lblTituloY.AutoSize = true;
            this.lblTituloY.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloY.Location = new System.Drawing.Point(59, 405);
            this.lblTituloY.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTituloY.Name = "lblTituloY";
            this.lblTituloY.Size = new System.Drawing.Size(161, 23);
            this.lblTituloY.TabIndex = 72;
            this.lblTituloY.Text = "PROCESOS PARA Y";
            this.lblTituloY.Visible = false;
            // 
            // lblTituloX
            // 
            this.lblTituloX.AutoSize = true;
            this.lblTituloX.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloX.Location = new System.Drawing.Point(47, 267);
            this.lblTituloX.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTituloX.Name = "lblTituloX";
            this.lblTituloX.Size = new System.Drawing.Size(172, 23);
            this.lblTituloX.TabIndex = 71;
            this.lblTituloX.Text = "PROCCESOS PARA X";
            this.lblTituloX.Visible = false;
            this.lblTituloX.Click += new System.EventHandler(this.lblTituloX_Click);
            // 
            // lblY
            // 
            this.lblY.AutoSize = true;
            this.lblY.Location = new System.Drawing.Point(240, 444);
            this.lblY.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblY.Name = "lblY";
            this.lblY.Size = new System.Drawing.Size(20, 23);
            this.lblY.TabIndex = 70;
            this.lblY.Text = "2";
            this.lblY.Visible = false;
            // 
            // lblX
            // 
            this.lblX.AutoSize = true;
            this.lblX.Location = new System.Drawing.Point(240, 345);
            this.lblX.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblX.Name = "lblX";
            this.lblX.Size = new System.Drawing.Size(17, 23);
            this.lblX.TabIndex = 69;
            this.lblX.Text = "1";
            this.lblX.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(57, 201);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(165, 23);
            this.label6.TabIndex = 68;
            this.label6.Text = "PROCEDIMIENTOS";
            this.label6.Visible = false;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(623, 754);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 46);
            this.label9.TabIndex = 67;
            this.label9.Text = "y";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(623, 654);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 46);
            this.label7.TabIndex = 66;
            this.label7.Text = "x";
            // 
            // lblMostrarSoluY
            // 
            this.lblMostrarSoluY.AutoSize = true;
            this.lblMostrarSoluY.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarSoluY.Location = new System.Drawing.Point(258, 754);
            this.lblMostrarSoluY.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMostrarSoluY.Name = "lblMostrarSoluY";
            this.lblMostrarSoluY.Size = new System.Drawing.Size(265, 46);
            this.lblMostrarSoluY.TabIndex = 65;
            this.lblMostrarSoluY.Text = "SOLUCION Y";
            this.lblMostrarSoluY.Visible = false;
            // 
            // lblMostrarSoluc
            // 
            this.lblMostrarSoluc.AutoSize = true;
            this.lblMostrarSoluc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarSoluc.Location = new System.Drawing.Point(258, 654);
            this.lblMostrarSoluc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMostrarSoluc.Name = "lblMostrarSoluc";
            this.lblMostrarSoluc.Size = new System.Drawing.Size(266, 46);
            this.lblMostrarSoluc.TabIndex = 64;
            this.lblMostrarSoluc.Text = "SOLUCION X";
            this.lblMostrarSoluc.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(172, 123);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 29);
            this.label5.TabIndex = 63;
            this.label5.Text = "+";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(172, 41);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 29);
            this.label4.TabIndex = 62;
            this.label4.Text = "+";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(283, 38);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 29);
            this.label3.TabIndex = 61;
            this.label3.Text = "=";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(283, 122);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 29);
            this.label2.TabIndex = 60;
            this.label2.Text = "=";
            // 
            // txta2
            // 
            this.txta2.Location = new System.Drawing.Point(94, 122);
            this.txta2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.txta2.Name = "txta2";
            this.txta2.Size = new System.Drawing.Size(61, 30);
            this.txta2.TabIndex = 59;
            // 
            // txtb2
            // 
            this.txtb2.Location = new System.Drawing.Point(212, 122);
            this.txtb2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.txtb2.Name = "txtb2";
            this.txtb2.Size = new System.Drawing.Size(60, 30);
            this.txtb2.TabIndex = 58;
            // 
            // txtc2
            // 
            this.txtc2.Location = new System.Drawing.Point(323, 125);
            this.txtc2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.txtc2.Name = "txtc2";
            this.txtc2.Size = new System.Drawing.Size(48, 30);
            this.txtc2.TabIndex = 57;
            // 
            // txtb1
            // 
            this.txtb1.Location = new System.Drawing.Point(212, 37);
            this.txtb1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.txtb1.Name = "txtb1";
            this.txtb1.Size = new System.Drawing.Size(60, 30);
            this.txtb1.TabIndex = 56;
            // 
            // txtc1
            // 
            this.txtc1.Location = new System.Drawing.Point(323, 34);
            this.txtc1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.txtc1.Name = "txtc1";
            this.txtc1.Size = new System.Drawing.Size(48, 30);
            this.txtc1.TabIndex = 55;
            // 
            // txta1
            // 
            this.txta1.Location = new System.Drawing.Point(94, 37);
            this.txta1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.txta1.Name = "txta1";
            this.txta1.Size = new System.Drawing.Size(61, 30);
            this.txta1.TabIndex = 54;
            // 
            // IGUALACION
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1031, 896);
            this.Controls.Add(this.lblTituloY);
            this.Controls.Add(this.lblTituloX);
            this.Controls.Add(this.lblY);
            this.Controls.Add(this.lblX);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblMostrarSoluY);
            this.Controls.Add(this.lblMostrarSoluc);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txta2);
            this.Controls.Add(this.txtb2);
            this.Controls.Add(this.txtc2);
            this.Controls.Add(this.txtb1);
            this.Controls.Add(this.txtc1);
            this.Controls.Add(this.txta1);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnResolver);
            this.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.Name = "IGUALACION";
            this.Text = "IGUALACION";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnResolver;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Label lblTituloY;
        private System.Windows.Forms.Label lblTituloX;
        private System.Windows.Forms.Label lblY;
        private System.Windows.Forms.Label lblX;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblMostrarSoluY;
        private System.Windows.Forms.Label lblMostrarSoluc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txta2;
        private System.Windows.Forms.TextBox txtb2;
        private System.Windows.Forms.TextBox txtc2;
        private System.Windows.Forms.TextBox txtb1;
        private System.Windows.Forms.TextBox txtc1;
        private System.Windows.Forms.TextBox txta1;
    }
}