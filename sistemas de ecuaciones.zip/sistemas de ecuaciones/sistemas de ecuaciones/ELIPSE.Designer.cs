﻿namespace sistemas_de_ecuaciones
{
    partial class ELIPSE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.txtCenterX = new System.Windows.Forms.TextBox();
            this.txtCenterY = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblEquation = new System.Windows.Forms.Label();
            this.txtSemiMajorAxis = new System.Windows.Forms.TextBox();
            this.txtSemiMinorAxis = new System.Windows.Forms.TextBox();
            this.lblProcedure = new System.Windows.Forms.Label();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCenterX
            // 
            this.txtCenterX.Location = new System.Drawing.Point(1896, 46);
            this.txtCenterX.Margin = new System.Windows.Forms.Padding(4);
            this.txtCenterX.Name = "txtCenterX";
            this.txtCenterX.Size = new System.Drawing.Size(132, 22);
            this.txtCenterX.TabIndex = 0;
            // 
            // txtCenterY
            // 
            this.txtCenterY.Location = new System.Drawing.Point(2053, 46);
            this.txtCenterY.Margin = new System.Windows.Forms.Padding(4);
            this.txtCenterY.Name = "txtCenterY";
            this.txtCenterY.Size = new System.Drawing.Size(132, 22);
            this.txtCenterY.TabIndex = 1;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(2067, 171);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(4);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(100, 28);
            this.btnCalcular.TabIndex = 2;
            this.btnCalcular.Text = "button1";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblEquation
            // 
            this.lblEquation.AutoSize = true;
            this.lblEquation.Location = new System.Drawing.Point(1893, 266);
            this.lblEquation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEquation.Name = "lblEquation";
            this.lblEquation.Size = new System.Drawing.Size(44, 16);
            this.lblEquation.TabIndex = 3;
            this.lblEquation.Text = "label1";
            // 
            // txtSemiMajorAxis
            // 
            this.txtSemiMajorAxis.Location = new System.Drawing.Point(2216, 44);
            this.txtSemiMajorAxis.Margin = new System.Windows.Forms.Padding(4);
            this.txtSemiMajorAxis.Name = "txtSemiMajorAxis";
            this.txtSemiMajorAxis.Size = new System.Drawing.Size(132, 22);
            this.txtSemiMajorAxis.TabIndex = 4;
            // 
            // txtSemiMinorAxis
            // 
            this.txtSemiMinorAxis.Location = new System.Drawing.Point(2379, 44);
            this.txtSemiMinorAxis.Margin = new System.Windows.Forms.Padding(4);
            this.txtSemiMinorAxis.Name = "txtSemiMinorAxis";
            this.txtSemiMinorAxis.Size = new System.Drawing.Size(132, 22);
            this.txtSemiMinorAxis.TabIndex = 5;
            // 
            // lblProcedure
            // 
            this.lblProcedure.AutoSize = true;
            this.lblProcedure.Location = new System.Drawing.Point(2237, 266);
            this.lblProcedure.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProcedure.Name = "lblProcedure";
            this.lblProcedure.Size = new System.Drawing.Size(108, 16);
            this.lblProcedure.TabIndex = 8;
            this.lblProcedure.Text = "lblProcedimiento";
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(51, 171);
            this.chart1.Margin = new System.Windows.Forms.Padding(4);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(1795, 1026);
            this.chart1.TabIndex = 9;
            this.chart1.Text = "chart1";
            // 
            // ELIPSE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2404, 1055);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.lblProcedure);
            this.Controls.Add(this.txtSemiMinorAxis);
            this.Controls.Add(this.txtSemiMajorAxis);
            this.Controls.Add(this.lblEquation);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtCenterY);
            this.Controls.Add(this.txtCenterX);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ELIPSE";
            this.Text = "ELIPSE";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ELIPSE_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCenterX;
        private System.Windows.Forms.TextBox txtCenterY;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblEquation;
        private System.Windows.Forms.TextBox txtSemiMajorAxis;
        private System.Windows.Forms.TextBox txtSemiMinorAxis;
        private System.Windows.Forms.Label lblProcedure;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
    }
}